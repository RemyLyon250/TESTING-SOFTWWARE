package WarehouseManagement24184.example.WarehouseManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehouseManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
